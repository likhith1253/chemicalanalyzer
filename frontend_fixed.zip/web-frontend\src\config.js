export const API_BASE_URL = "https://chemicalanalyzer.onrender.com/api";
